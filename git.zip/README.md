# endstone-serversign

Panneaux cliquables qui exécutent des commandes, pour Endstone (Minecraft Bedrock).

## Utilisation
Deux modes, choisis automatiquement selon votre version d'Endstone :

**Versions publiées (<= 0.11.12) — pas d'API des panneaux**
1. Posez un panneau et écrivez son texte normalement (éditeur vanilla).
2. `/serversign create`, puis clic droit sur le panneau : un formulaire demande les commandes et l'exécutant (joueur / console).
3. `/serversign cancel`. Désormais, un clic droit exécute les commandes.

**Branche develop / futures versions — API des panneaux**
Le formulaire remplace l'éditeur vanilla et demande aussi les 4 lignes de texte.

`{player}` est remplacé par le pseudo du joueur. Pour modifier un ServerSign : `/serversign create` puis clic droit.

## Permissions
| Permission | Défaut | Rôle |
|---|---|---|
| `serversign.command.serversign` | op | utiliser `/serversign` |
| `serversign.create` | op | créer / modifier |
| `serversign.console` | op | choisir « Console » comme exécutant |
| `serversign.break` | op | casser un panneau ServerSign |
| `serversign.use` | tous | cliquer sur un panneau |

## Installation
`pip install build && python -m build` puis copier le `.whl` de `dist/` dans `plugins/`.
